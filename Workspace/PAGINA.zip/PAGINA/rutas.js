// Importamos Express
const express = require('express');

// Creamos un router para definir las rutas
const router = express.Router();

// Exportamos una función que recibe la conexión 'db' como parámetro.
// Esto permite usar el mismo router con diferentes bases de datos.
module.exports = (db) => 

  // ==================== LEER TODOS LOS USUARIOS ====================
  // Ruta GET: devuelve la lista completa de usuarios
  router.get('/estudiantes', (req, res) => {
    db.query('SELECT * FROM estudiantes', (err, results) => {
      if (err) return res.status(500).json({ error: err }); // Error de servidor
      res.json(results); // Devuelve todos los registros
    });
  });

  // ==================== LEER UN USUARIO POR ID ====================
  // Ruta GET con parámetro :id → devuelve un usuario específico
  router.get('/estudiantes/:id', (req, res) => {
    const { id } = req.params; // Se obtiene el id desde la URL
    db.query('SELECT * FROM estudiantes WHERE id = ?', [id], (err, result) => {
      if (err) return res.status(500).json({ error: err }); // Error de servidor
      if (result.length === 0) return res.status(404).json({ mensaje: 'estudiante no encontrado' }); // No existe
      res.json(result[0]); // Devuelve el usuario encontrado
    });
  });

  // ==================== CREAR USUARIO ====================
  // Ruta POST: inserta un nuevo usuario en la base de datos
  router.post('/estudiantes', (req, res) => {
    const { nombre, email } = req.body; // Datos enviados desde el cliente
    db.query(
      'INSERT INTO estudiante (nombre, email) VALUES (?, ?)', // Consulta SQL
      [id_estudiante, nombre, apellido, correo, contrasena], // Valores a insertar
      (err, result) => {
        if (err) return res.status(500).json({ error: err }); // Error de servidor
        res.json({ mensaje: 'estudiante creado', id: result.insertId }); // Respuesta con el id generado
      }
    );
  });